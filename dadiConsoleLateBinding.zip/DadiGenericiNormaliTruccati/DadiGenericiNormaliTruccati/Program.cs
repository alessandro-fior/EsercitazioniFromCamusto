using System;
using System.Collections.Generic;
using System.Text;

namespace DadiGenericiNormaliTruccati
{

  //invece di usare tante costanti si pu� definire una enumerazione
  //una variabile che ha come tipo una enumerazione pu� assumere come
  //valori solo uno di quelli elencati
  enum LivelliTrucco { Poco, Ladro, Ladrone };

  class DadiGenerici
  {
    protected int numFacce = 6;

    protected int UltimoLancio = 0;

    //predispongo un generatore per non
    //doverlo creare ad ogni lancio
    protected Random generatore = null;

    public DadiGenerici(int _numFacce)
    {
      numFacce = _numFacce;
      generatore = new Random();
    }

    //LATE BINDING!!
    virtual public int Lancia() { return 0; }

  }

  class Dadi : DadiGenerici
  {

    public Dadi(int _numFacce)
      : base(_numFacce)
    {
      //quando creo un dado lo lancio in automatico una prima volta
      Lancia();
    }

    //LATE BINDING!!
    override public int Lancia()
    {
      UltimoLancio = generatore.Next(1, numFacce + 1);
      return UltimoLancio;
    }

    public int getValoreDado()
    { return UltimoLancio; }
  }



  class DadiTruccati : DadiGenerici
  {
    int FacciaTruccata = 0;
    LivelliTrucco QuantoTrucco = LivelliTrucco.Poco;

    public DadiTruccati(int numFacce, int _facciaTruccata, LivelliTrucco _QuantoTrucco)
      : base(numFacce)
    {
      FacciaTruccata = _facciaTruccata; QuantoTrucco = _QuantoTrucco;
    }

    //LATE BINDING!!
    override public int Lancia()
    {

      //per truccare il dado aggiungo pi� facce di quelle richieste
      //se nel lancio esce una faccia oltre quelle reali considero
      //estratta quella truccata; quindi pi� facce extra aggiungo
      //e maggiore diventa la probabililit� che venga estratta quella truccata ...     

      //si aggiunge 1 a QuantoTrucco perch� i valori delle enumerazioni dal punto di vista del loro
      //valore numerico parte da 0
      int LancioTruccato = generatore.Next(1, 1 + numFacce + 3 * ((int)QuantoTrucco + 1));

      //se � uscita una faccia oltre quelle reali, fai in modo che sembri
      //estratta la faccia truccata
      if (LancioTruccato > numFacce || LancioTruccato == FacciaTruccata)
        UltimoLancio = FacciaTruccata;
      else
        UltimoLancio = LancioTruccato;

      return UltimoLancio;
    }
  }


  class Program
  {

    static void Main(string[] args)
    {

      //vettore di 1000 dadi generici
      DadiGenerici[] VettoreDadi = new DadiGenerici[1000];
      int normali = 0, truccati = 0;

      //creo a caso 1000 dadi
      Random x = new Random(); //per scegliere i dati dei dadi a caso ...
      for (int i = 0; i < 1000; i++)
      {
        int facce = x.Next(15) + 2; //da 2 a 16 facce

        switch (x.Next(2))
        {
          case 0: //normale ...
            VettoreDadi[i] = new Dadi(facce);
            normali++;
            break;
          case 1: //truccato
            VettoreDadi[i] = new DadiTruccati(facce, x.Next(facce) + 1, (LivelliTrucco)x.Next(3));
            truccati++;
            break;
        }
      }


      float media = 0;
      for (int serie = 1; serie <= 10; serie++)
        foreach (DadiGenerici d in VettoreDadi)
          media += d.Lancia();
      media /= 10000;
      Console.WriteLine("Normali {0}, Truccati {1}, media {2}", normali, truccati, media );

    }
  }
}
