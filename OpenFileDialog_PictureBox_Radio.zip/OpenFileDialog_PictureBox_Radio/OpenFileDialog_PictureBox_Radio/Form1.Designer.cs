﻿namespace WindowsApplication1
{
  partial class Form1
  {
    /// <summary>
    /// Variabile di progettazione necessaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Liberare le risorse in uso.
    /// </summary>
    /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Codice generato da Progettazione Windows Form

    /// <summary>
    /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
    /// il contenuto del metodo con l'editor di codice.
    /// </summary>
    private void InitializeComponent()
    {
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.ScegliImgOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
      this.ScegliImgBtn = new System.Windows.Forms.Button();
      this.OriginaleRadio = new System.Windows.Forms.RadioButton();
      this.StretchRadio = new System.Windows.Forms.RadioButton();
      this.ZoomRadio = new System.Windows.Forms.RadioButton();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.SuspendLayout();
      // 
      // pictureBox1
      // 
      this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.pictureBox1.Location = new System.Drawing.Point(0, 28);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(387, 115);
      this.pictureBox1.TabIndex = 0;
      this.pictureBox1.TabStop = false;
      // 
      // ScegliImgOpenFileDialog
      // 
      this.ScegliImgOpenFileDialog.FileName = "openFileDialog1";
      this.ScegliImgOpenFileDialog.Filter = "Jpeg|*.jpg|Bitmap|*.bmp";
      // 
      // ScegliImgBtn
      // 
      this.ScegliImgBtn.Location = new System.Drawing.Point(98, 149);
      this.ScegliImgBtn.Name = "ScegliImgBtn";
      this.ScegliImgBtn.Size = new System.Drawing.Size(148, 23);
      this.ScegliImgBtn.TabIndex = 1;
      this.ScegliImgBtn.Text = "Scegli Immagine";
      this.ScegliImgBtn.UseVisualStyleBackColor = true;
      this.ScegliImgBtn.Click += new System.EventHandler(this.button1_Click);
      // 
      // OriginaleRadio
      // 
      this.OriginaleRadio.AutoSize = true;
      this.OriginaleRadio.Checked = true;
      this.OriginaleRadio.Location = new System.Drawing.Point(418, 43);
      this.OriginaleRadio.Name = "OriginaleRadio";
      this.OriginaleRadio.Size = new System.Drawing.Size(66, 17);
      this.OriginaleRadio.TabIndex = 2;
      this.OriginaleRadio.TabStop = true;
      this.OriginaleRadio.Text = "Originale";
      this.OriginaleRadio.UseVisualStyleBackColor = true;
      this.OriginaleRadio.Click += new System.EventHandler(this.OriginaleRadio_Click);
      // 
      // StretchRadio
      // 
      this.StretchRadio.AutoSize = true;
      this.StretchRadio.Location = new System.Drawing.Point(418, 78);
      this.StretchRadio.Name = "StretchRadio";
      this.StretchRadio.Size = new System.Drawing.Size(59, 17);
      this.StretchRadio.TabIndex = 3;
      this.StretchRadio.Text = "Stretch";
      this.StretchRadio.UseVisualStyleBackColor = true;
      this.StretchRadio.Click += new System.EventHandler(this.StretchRadio_Click);
      // 
      // ZoomRadio
      // 
      this.ZoomRadio.AutoSize = true;
      this.ZoomRadio.Location = new System.Drawing.Point(418, 117);
      this.ZoomRadio.Name = "ZoomRadio";
      this.ZoomRadio.Size = new System.Drawing.Size(52, 17);
      this.ZoomRadio.TabIndex = 4;
      this.ZoomRadio.Text = "Zoom";
      this.ZoomRadio.UseVisualStyleBackColor = true;
      this.ZoomRadio.Click += new System.EventHandler(this.ZoomRadio_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(523, 273);
      this.Controls.Add(this.ZoomRadio);
      this.Controls.Add(this.StretchRadio);
      this.Controls.Add(this.OriginaleRadio);
      this.Controls.Add(this.ScegliImgBtn);
      this.Controls.Add(this.pictureBox1);
      this.Name = "Form1";
      this.Text = "Form1";
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.PictureBox pictureBox1;
    private System.Windows.Forms.OpenFileDialog ScegliImgOpenFileDialog;
    private System.Windows.Forms.Button ScegliImgBtn;
    private System.Windows.Forms.RadioButton OriginaleRadio;
    private System.Windows.Forms.RadioButton StretchRadio;
    private System.Windows.Forms.RadioButton ZoomRadio;
  }
}

