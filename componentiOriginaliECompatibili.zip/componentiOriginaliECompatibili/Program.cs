﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace componentiOriginaliECompatibili
{
    class Program
    {
        static void Main(string[] args)
        {
            componenti[] computer = new componenti[15];
            int numComponenti = 0; string descrizione = "";
            double costo = 0;  double maggiorazione = 0;
            string tipo = "";

            //SOLUZIONE MINIMALE DEL CARICAMENTO (tre componenti, niente ciclo) 
            Console.WriteLine("inserire descrizione componente n. 1");
            descrizione = Console.ReadLine();
            Console.WriteLine("inserire costo ingrosso componente n. 1");
            costo = Convert.ToDouble( Console.ReadLine());
            Console.WriteLine("inserire maggiorazione componente n. 1");
            maggiorazione = Convert.ToDouble(Console.ReadLine());
            computer[numComponenti] = new componentiOriginali(descrizione, costo, maggiorazione);
            numComponenti++;

            //ovviamente su carta potevate indicare 'similmente per il secondo componente'
            //e non scrivere il codice per il seguente componente identico al primo
            Console.WriteLine("inserire descrizione componente n. 2");
            descrizione = Console.ReadLine();
            Console.WriteLine("inserire costo ingrosso componente n. 1");
            costo = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("inserire maggiorazione componente n. 1");
            maggiorazione = Convert.ToDouble(Console.ReadLine());
            computer[numComponenti] = new componentiOriginali(descrizione, costo, maggiorazione);
            numComponenti++;

            Console.WriteLine("inserire descrizione componente n. 3");
            descrizione = Console.ReadLine();
            Console.WriteLine("inserire costo ingrosso componente n. 3");
            costo = Convert.ToDouble(Console.ReadLine());
            computer[numComponenti] = new componentiCompatibili(descrizione, costo);
            numComponenti++;

            //SOLUZIONE OTTIMALE, CARICAMENTO CON CICLO
            numComponenti = 0;
            do
            {
                Console.WriteLine("Tipo componente (O=originale, C=compatibile, FINE=termina programma");
                tipo = Console.ReadLine();

                if (tipo.ToUpper() == "O" || tipo.ToUpper() == "C")
                {
                    Console.WriteLine("inserire descrizione componente n. {0}", numComponenti + 1);
                    descrizione = Console.ReadLine();
                    Console.WriteLine("inserire costo ingrosso componente n. {0}", numComponenti + 1);
                    costo = Convert.ToDouble(Console.ReadLine());
                }
              
                if (tipo.ToUpper() =="C") //notare l'uso del post incremento tra parentesi
                    computer[numComponenti++] = new componentiCompatibili(descrizione, costo);
                else
                    if (tipo.ToUpper() == "O")
                    {
                        Console.WriteLine("inserire maggiorazione componente n. {0}", numComponenti);
                        maggiorazione = Convert.ToDouble(Console.ReadLine());
                        computer[numComponenti++] = new componentiOriginali(descrizione, costo, maggiorazione);
                   }
            } while (tipo.ToUpper() != "FINE" && numComponenti<15);


            //IN OGNI CASO (CARICAMENTO SEMPLICE O CON CICLO) SI PROSEGUE POI COSI':
            double totale = 0;
            for (int i = 0; i < numComponenti; i++)
                totale += computer[i].costoTotale();

            Console.Write("Costo totale: {0}", totale);
            while (!Console.KeyAvailable); //attende pressione di un tasto

        }
    }
}
