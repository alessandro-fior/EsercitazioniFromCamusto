﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace componentiOriginaliECompatibili
{
    class componenti
    {
        string descrizione = ""; double costoIngrosso = 0; int percIva = 20;

        public componenti(string desc, double costo)
        { descrizione = desc; costoIngrosso = costo; }

        virtual public double costoTotale()
        { return costoIngrosso * (1 + percIva / 100); }
    }

    class componentiOriginali : componenti
    {
        double maggiorazione = 0;

        public componentiOriginali(string desc, double costo, double magg) :
            base(desc, costo)
        { maggiorazione = magg; }

        override public double costoTotale()
        { return base.costoTotale() + maggiorazione; }
        /* oppure (mettendo protected percIva e costoIngrosso)
         * { return costoIngrosso * (1 + percIva / 100) + maggiorazione; } */
         
    
    }

    class componentiCompatibili : componenti
    {
        public componentiCompatibili(string desc, double costo) :
            base(desc, costo)  { }

        override public double costoTotale()
        { return base.costoTotale() * 0.75; }
        /* oppure (mettendo protected percIva e costoIngrosso)
          * { return (costoIngrosso * (1 + percIva / 100)) * 0.75; } */
         

    }
}
