﻿namespace DateTimePicker_numericUpDown_treeView
{
  partial class Form1
  {
    /// <summary>
    /// Variabile di progettazione necessaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Liberare le risorse in uso.
    /// </summary>
    /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Codice generato da Progettazione Windows Form

    /// <summary>
    /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
    /// il contenuto del metodo con l'editor di codice.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.Calendario = new System.Windows.Forms.DateTimePicker();
      this.albero = new System.Windows.Forms.TreeView();
      this.NumeroGiorni = new System.Windows.Forms.NumericUpDown();
      this.AggiungiBtn = new System.Windows.Forms.Button();
      this.TogliBtn = new System.Windows.Forms.Button();
      this.Espandibtn = new System.Windows.Forms.Button();
      this.ListaImmaginiMesiELuna = new System.Windows.Forms.ImageList(this.components);
      this.label1 = new System.Windows.Forms.Label();
      this.panel1 = new System.Windows.Forms.Panel();
      ((System.ComponentModel.ISupportInitialize)(this.NumeroGiorni)).BeginInit();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // Calendario
      // 
      this.Calendario.Location = new System.Drawing.Point(13, 31);
      this.Calendario.Name = "Calendario";
      this.Calendario.Size = new System.Drawing.Size(207, 20);
      this.Calendario.TabIndex = 0;
      // 
      // albero
      // 
      this.albero.BackColor = System.Drawing.Color.Snow;
      this.albero.ImageIndex = 0;
      this.albero.ImageList = this.ListaImmaginiMesiELuna;
      this.albero.Location = new System.Drawing.Point(24, 183);
      this.albero.Name = "albero";
      this.albero.SelectedImageIndex = 0;
      this.albero.Size = new System.Drawing.Size(242, 278);
      this.albero.TabIndex = 1;
      // 
      // NumeroGiorni
      // 
      this.NumeroGiorni.Location = new System.Drawing.Point(82, 82);
      this.NumeroGiorni.Name = "NumeroGiorni";
      this.NumeroGiorni.Size = new System.Drawing.Size(67, 20);
      this.NumeroGiorni.TabIndex = 2;
      // 
      // AggiungiBtn
      // 
      this.AggiungiBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.AggiungiBtn.Location = new System.Drawing.Point(13, 80);
      this.AggiungiBtn.Name = "AggiungiBtn";
      this.AggiungiBtn.Size = new System.Drawing.Size(39, 22);
      this.AggiungiBtn.TabIndex = 3;
      this.AggiungiBtn.Text = "+";
      this.AggiungiBtn.UseVisualStyleBackColor = true;
      this.AggiungiBtn.Click += new System.EventHandler(this.AggiungiBtn_Click);
      // 
      // TogliBtn
      // 
      this.TogliBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.TogliBtn.Location = new System.Drawing.Point(186, 80);
      this.TogliBtn.Name = "TogliBtn";
      this.TogliBtn.Size = new System.Drawing.Size(34, 23);
      this.TogliBtn.TabIndex = 4;
      this.TogliBtn.Text = "-";
      this.TogliBtn.UseVisualStyleBackColor = true;
      this.TogliBtn.Click += new System.EventHandler(this.TogliBtn_Click);
      // 
      // Espandibtn
      // 
      this.Espandibtn.Location = new System.Drawing.Point(63, 154);
      this.Espandibtn.Name = "Espandibtn";
      this.Espandibtn.Size = new System.Drawing.Size(151, 23);
      this.Espandibtn.TabIndex = 5;
      this.Espandibtn.Text = "MOSTRA INTERO ANNO";
      this.Espandibtn.UseVisualStyleBackColor = true;
      this.Espandibtn.Click += new System.EventHandler(this.Espandibtn_Click);
      // 
      // ListaImmaginiMesiELuna
      // 
      this.ListaImmaginiMesiELuna.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ListaImmaginiMesiELuna.ImageStream")));
      this.ListaImmaginiMesiELuna.TransparentColor = System.Drawing.Color.Transparent;
      this.ListaImmaginiMesiELuna.Images.SetKeyName(0, "gennaio.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(1, "febbraio.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(2, "marzo.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(3, "aprile.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(4, "maggio.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(5, "giugno.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(6, "luglio.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(7, "agosto.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(8, "settembre.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(9, "ottobre.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(10, "novembre.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(11, "dicembre.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(12, "falceLuna.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(13, "quartoDiLuna.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(14, "mezzaLunaCalante.jpg");
      this.ListaImmaginiMesiELuna.Images.SetKeyName(15, "lunaPiena.jpg");
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(43, 63);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(147, 13);
      this.label1.TabIndex = 6;
      this.label1.Text = "AGGIUNGI O TOGLI GIORNI";
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.DeepSkyBlue;
      this.panel1.Controls.Add(this.label1);
      this.panel1.Controls.Add(this.TogliBtn);
      this.panel1.Controls.Add(this.AggiungiBtn);
      this.panel1.Controls.Add(this.NumeroGiorni);
      this.panel1.Controls.Add(this.Calendario);
      this.panel1.Location = new System.Drawing.Point(24, 22);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(242, 115);
      this.panel1.TabIndex = 7;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(284, 460);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.Espandibtn);
      this.Controls.Add(this.albero);
      this.Name = "Form1";
      this.Text = "Form1";
      ((System.ComponentModel.ISupportInitialize)(this.NumeroGiorni)).EndInit();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.DateTimePicker Calendario;
    private System.Windows.Forms.TreeView albero;
    private System.Windows.Forms.NumericUpDown NumeroGiorni;
    private System.Windows.Forms.Button AggiungiBtn;
    private System.Windows.Forms.Button TogliBtn;
    private System.Windows.Forms.Button Espandibtn;
    private System.Windows.Forms.ImageList ListaImmaginiMesiELuna;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Panel panel1;
  }
}

