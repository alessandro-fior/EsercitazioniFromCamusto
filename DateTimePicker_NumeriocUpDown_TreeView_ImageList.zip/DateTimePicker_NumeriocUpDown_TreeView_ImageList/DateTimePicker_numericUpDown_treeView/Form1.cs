using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DateTimePicker_numericUpDown_treeView
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void Espandibtn_Click(object sender, EventArgs e)
    {

      //distruggo vecchio contenuto
      if (albero.Nodes.Count > 0)
        albero.Nodes.Clear();

      //creo data al primo gennaio dello stesso anno scelto nel datepicker
      DateTime d = new DateTime(Calendario.Value.Year, 1, 1);
      
     //per ogni mese creo un nodo al livello superiore del tree view
      for (int i = 0; i <= 11; i++)
      {
        DateTime primoDelMese=d.AddMonths(i);

        //crea il nodo
        albero.Nodes.Add(new TreeNode(primoDelMese.ToLongDateString()));
        albero.Nodes[i].ImageIndex = i;
        
        //per ogni nodo/mese crea tanti nodi figli quanti sono i giorni
        for (int g = 0; g <= DateTime.DaysInMonth(d.Year, i + 1) - 1; g++)
        {
          albero.Nodes[i].Nodes.Add(new TreeNode(primoDelMese.AddDays(g).ToLongDateString()));
          albero.Nodes[i].Nodes[g].ImageIndex = 12 + g % 4;
        }
    
        

      }
    }

    private void AggiungiBtn_Click(object sender, EventArgs e)
    {
      Calendario.Value = Calendario.Value.AddDays( Decimal.ToDouble(NumeroGiorni.Value));
    }

    private void TogliBtn_Click(object sender, EventArgs e)
    {
      Calendario.Value = Calendario.Value.AddDays(-Decimal.ToDouble(NumeroGiorni.Value));
    }
  }
}